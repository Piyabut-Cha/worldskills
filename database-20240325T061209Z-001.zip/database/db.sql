-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2024 at 06:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tfc`
--

-- --------------------------------------------------------

--
-- Table structure for table `competitions`
--

CREATE TABLE `competitions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `max_teams` tinyint(4) NOT NULL,
  `group_count` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `competitions`
--

INSERT INTO `competitions` (`id`, `name`, `slug`, `max_teams`, `group_count`) VALUES
(1, 'Bangkok Cup', 'bangkok-cup', 16, 16),
(2, 'Khon Kaen Cup', 'khon-kaen-cup', 4, 2),
(3, 'Buriram Cup', 'buriram-cup', 8, 4);

-- --------------------------------------------------------

--
-- Table structure for table `competition_allowed_provinces`
--

CREATE TABLE `competition_allowed_provinces` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `competition_id` bigint(20) UNSIGNED NOT NULL,
  `province_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `competition_allowed_provinces`
--

INSERT INTO `competition_allowed_provinces` (`id`, `competition_id`, `province_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 1, 12),
(13, 1, 13),
(14, 2, 5),
(15, 2, 8),
(16, 3, 2),
(17, 3, 5),
(18, 3, 8),
(19, 3, 9);

-- --------------------------------------------------------

--
-- Table structure for table `competition_registered_teams`
--

CREATE TABLE `competition_registered_teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `competition_id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `competition_registered_teams`
--

INSERT INTO `competition_registered_teams` (`id`, `competition_id`, `team_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 1, 12),
(13, 1, 13),
(14, 1, 14),
(15, 1, 15),
(16, 1, 16),
(17, 2, 7),
(18, 2, 11),
(19, 3, 4),
(20, 3, 7),
(21, 3, 11),
(22, 3, 12);

-- --------------------------------------------------------

--
-- Table structure for table `provinces`
--

CREATE TABLE `provinces` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `provinces`
--

INSERT INTO `provinces` (`id`, `name`) VALUES
(1, 'Bangkok'),
(2, 'Buriram'),
(3, 'Chiangrai'),
(4, 'Chonburi'),
(5, 'Khon Kaen'),
(6, 'Lampang'),
(7, 'Lamphun'),
(8, 'Nakhon Ratchasima'),
(9, 'Nong Bua Lamphu'),
(10, 'Nonthaburi'),
(11, 'Prachuap Khiri Khan'),
(12, 'Ratchaburi\r\n'),
(13, 'Sukhothai\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `province_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `code`, `logo`, `province_id`) VALUES
(1, 'BEC Tero Sasana FC', 'BEC', '/images/logos/bec-tero-sasana-fc/logo.png', 1),
(2, 'Bangkok Glass FC', 'Bangkok', '/images/logos/bangkok-glass-fc/logo.png', 1),
(3, 'Bangkok United FC', 'Bangkok', '/images/logos/bangkok-united-fc/logo.png', 1),
(4, 'Buriram United FC', 'Buriram', '/images/logos/buriram-united-fc/logo.png', 2),
(5, 'Chiangrai United FC', 'Chiangrai', '/images/logos/chiangrai-united-fc/logo.png', 3),
(6, 'Chonburi FC', 'Chonburi', '/images/logos/chonburi-fc/logo.png', 4),
(7, 'Khon Kaen United FC', 'Khon', '/images/logos/khon-kaen-united-fc/logo.png', 5),
(8, 'Lampang FC', 'Lampang', '/images/logos/lampang-fc/logo.png', 6),
(9, 'Lamphun Warrior FC', 'Lamphun', '/images/logos/lamphun-warrior-fc/logo.png', 7),
(10, 'Muang Thong United', 'Muang', '/images/logos/muang-thong-united/logo.png', 10),
(11, 'Nakhon Ratchasima FC', 'Nakhon', '/images/logos/nakhon-ratchasima-fc/logo.png', 8),
(12, 'Nong Bua Pitchaya FC', 'Nong', '/images/logos/nong-bua-pitchaya-fc/logo.png', 9),
(13, 'Port FC', 'Port', '/images/logos/port-fc/logo.png', 1),
(14, 'Prachuap FC', 'Prachuap', '/images/logos/prachuap-fc/logo.png', 11),
(15, 'Ratchaburi Mitr Phol FC', 'Ratchaburi', '/images/logos/ratchaburi-mitr-phol-fc/logo.png', 12),
(16, 'Sukhothai FC', 'Sukhothai', '/images/logos/sukhothai-fc/logo.png', 13);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `competitions`
--
ALTER TABLE `competitions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `competitions_slug_unique` (`slug`);

--
-- Indexes for table `competition_allowed_provinces`
--
ALTER TABLE `competition_allowed_provinces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `competition_allowed_countries_competition_id_foreign` (`competition_id`),
  ADD KEY `competition_allowed_countries_country_id_foreign` (`province_id`);

--
-- Indexes for table `competition_registered_teams`
--
ALTER TABLE `competition_registered_teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `competition_registered_teams_competition_id_foreign` (`competition_id`),
  ADD KEY `competition_registered_teams_team_id_foreign` (`team_id`);

--
-- Indexes for table `provinces`
--
ALTER TABLE `provinces`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teams_country_id_foreign` (`province_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `competitions`
--
ALTER TABLE `competitions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `competition_allowed_provinces`
--
ALTER TABLE `competition_allowed_provinces`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `competition_registered_teams`
--
ALTER TABLE `competition_registered_teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `provinces`
--
ALTER TABLE `provinces`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `competition_allowed_provinces`
--
ALTER TABLE `competition_allowed_provinces`
  ADD CONSTRAINT `competition_allowed_countries_competition_id_foreign` FOREIGN KEY (`competition_id`) REFERENCES `competitions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `competition_allowed_countries_country_id_foreign` FOREIGN KEY (`province_id`) REFERENCES `provinces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `competition_registered_teams`
--
ALTER TABLE `competition_registered_teams`
  ADD CONSTRAINT `competition_registered_teams_competition_id_foreign` FOREIGN KEY (`competition_id`) REFERENCES `competitions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `competition_registered_teams_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `teams_country_id_foreign` FOREIGN KEY (`province_id`) REFERENCES `provinces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
